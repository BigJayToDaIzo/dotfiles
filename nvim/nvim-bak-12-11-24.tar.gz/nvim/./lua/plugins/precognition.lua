return {
	-- h: precog<C-d>
	-- Gutter hints for better motions
	"tris203/precognition.nvim",
	opts = {
		showBlankVirtLine = false,
	},
}
