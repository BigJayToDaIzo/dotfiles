return {
	"levouh/tint.nvim",
	config = function()
		require("tint").setup({
			tint = -65,
		})
	end,
}
