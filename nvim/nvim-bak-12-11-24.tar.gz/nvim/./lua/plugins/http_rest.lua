return {
	"rest-nvim/rest.nvim",
	config = function()
		require("rest-nvim").setup({})
	end,
}
