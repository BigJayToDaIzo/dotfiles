return {
	"mrcjkb/rustaceanvim",
	version = "^5.0.0",
	lazy = false,
	dap = { "mfussenegger/nvim-dap" },
}
