return {
	"ray-x/go.nvim",
}
