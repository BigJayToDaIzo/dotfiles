return {
	"kylechui/nvim-surround",
	config = function()
		require("nvim-surround").setup({
			-- Configure here yo!
		})
	end,
}
