~~Mason~~
    ~~Neodev.nvim~~
        ~~nvim-cmp section post nvim-cmp install~~
    ~~LSP:lspconfig & mason-lspconfig.nvim~~
    ~~FORMAT: conform & mason-conform~~
    ~~LINT:nvim-lint & mason-nvim-lint~~
    DAP:~~nvim-dap & nvim-dap-ui &~~ ~~nvim-neotest/nvim-nio~~ & nvim-dap-virtual-text & ~~mason-nvim-dap.nvim~~
~~NEOTEST~~
~~Trouble~~
NeoCodium?? (Bench Copilot)
GoQoL
~~Notifications~~
~~StatusLine~~
~~Flash~~
~~Treesitter
    Treesitter related modules like:
    Highlight, Incremental selection, Indentation, Folding
    Treesitter related plugins like:
    nvim-treesitter-context
    nvim-treesitter-textobjects~~
~~Telescope
    Telescope Plugins?~~
~~Greeter~~
~~Copilot~~
~~Completion:
    Snippets
    implement lazydev source~~
~~IndentBlankline~~
~~Git:
    Oil-Git-Status
    LazyGit
    Gitsigns~~
~~Fidget~~
~~Precognition~~
~~Hardtime~~
