return {
	"j-hui/fidget.nvim",
	lazy = true,
	opts = {},
}
