return {
	"tris203/precognition.nvim",
	event = "VeryLazy",
	opts = {
		showBlankVirtLine = false,
	},
}
