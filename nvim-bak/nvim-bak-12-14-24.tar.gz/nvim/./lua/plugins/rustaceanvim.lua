return {
	"mrcjkb/rustaceanvim",
	version = "^5",
	lazy = false,
}
