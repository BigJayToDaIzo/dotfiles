return {
	"windwp/nvim-autopairs",
	event = "InsertEnter",
	opts = {
		width = 100,
	},
}
