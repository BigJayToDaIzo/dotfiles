return {
	"adamkali/vaporlush",
	branch = "v2",
	lazy = false,
	priority = 1001,
	opts = {
		cache = true,
		style = "vapor",
		--style = 'blossom'
		--style = '1996'
	},
}
