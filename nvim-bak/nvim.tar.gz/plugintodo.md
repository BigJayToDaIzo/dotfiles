~~LazyPlugin~~
~~Lazydev.nvim~~ 
~~IndentBlankline 
    autoindent
    colored~~
~~FORMAT: conform & mason-conform~~
    ~~rust formatter (deprecated)~~
~~Mason~~
UI ~~update, dressing or Noice or other?~~
    modify/tweak dressing?
Copilot 
    FIX ANNOYING COPILOT GHOST TEST
    copilot can you disable your own ghost text?
    Mastering GH copilot for paired programming
~~COMPLETION:~~nvim-cmp~~
    completions for lsp
    copilot
    completions for git~~
LINT:~~nvim-lint & mason-nvim-lint~~
    ~~bolt on rust next~~
~~Telescope~~
    ~~Telescope Plugins bolt ons~~
    ~~Telescope keybinds~~
~~LSP:~~ 
    ~~lspconfig & mason-lspconfig.nvim~~
    ~~rust lsp~~
~~DAP:~~
    ~~nvim-neotest/nvim-nio~~
    ~~mason-nvim-dap.nvim~~ ~~telescope-dap~~
    ~~diagnostic keybinds~~
    ~~rust dap adapter~~
    ~~neotest~~
        ~~nvim-dap-ui stuffs~~
~~Git:~~
    ~~keybinds for gitsigns~~
~~WhichKey~~
~~Autopair~~
~~Fidget~~
~~Notifications~~
~~Flash~~
~~Trouble~~
~~TODOs~~
    telescope todo search
~~Precognition~~
~~:IMPORTANT: Hardtime MESSES UP MY MOUSE~~
 ~~it was hardtime,~~ on purpose like it says it does in the docs. 
~~Hardtime~~
GoQoL
NeoCodium?? (Bench Copilot) 
~~StatusLine~~
~~LazyGit~~
~~Gitsigns~~
~~Windline~~
~~Oil File-Tree~~
~~Oil-Git-Status~~
~~Treesitter~~
~~Nerdy~~
